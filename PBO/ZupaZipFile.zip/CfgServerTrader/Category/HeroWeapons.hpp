class Category_477 {
	class G36_C_SD_camo {
		type = "trade_weapons";
		buy[] ={2500,"Coins"};
		sell[] ={1250,"Coins"};
	};
	class M4A1_AIM_SD_camo {
		type = "trade_weapons";
		buy[] ={5000,"Coins"};
		sell[] ={2500,"Coins"};
	};
	class FN_FAL_ANPVS4 {
		type = "trade_weapons";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class SCAR_H_LNG_Sniper_SD {
		type = "trade_weapons";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class BAF_LRR_scoped {
		type = "trade_weapons";
		buy[] ={75000,"Coins"};
		sell[] ={37500,"Coins"};
	};
	class FN_FAL {
		type = "trade_weapons";
		buy[] ={5000,"Coins"};
		sell[] ={2500,"Coins"};
	};
	class Mk_48_DZ {
		type = "trade_weapons";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class M240_DZ {
		type = "trade_weapons";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
};
