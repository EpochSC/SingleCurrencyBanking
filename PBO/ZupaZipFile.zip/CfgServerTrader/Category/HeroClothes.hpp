class Category_476 {
	class Skin_CZ_Special_Forces_GL_DES_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Drake_Light_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Soldier_Sniper_PMC_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_FR_OHara_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_FR_Rodriguez_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_CZ_Soldier_Sniper_EP1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Graves_Light_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Soldier_Bodyguard_AA12_PMC_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Camo1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Rocket_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Sniper1_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Skin_Soldier1_DZ {
		type = "trade_items";
		buy[] ={1800,"Coins"};
		sell[] ={900,"Coins"};
	};
	class Skin_Soldier_TL_PMC_DZ {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
};
