class Category_606 {
	class M9SD {
		type = "trade_weapons";
		buy[] ={800,"Coins"};
		sell[] ={400,"Coins"};
	};
	class glock17_EP1 {
		type = "trade_weapons";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class Colt1911 {
		type = "trade_weapons";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class M9 {
		type = "trade_weapons";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class MakarovSD {
		type = "trade_weapons";
		buy[] ={800,"Coins"};
		sell[] ={400,"Coins"};
	};
	class revolver_gold_EP1 {
		type = "trade_weapons";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class Makarov {
		type = "trade_weapons";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class revolver_EP1 {
		type = "trade_weapons";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
};
class Category_674 {
	class M9SD {
		type = "trade_weapons";
		buy[] ={800,"Coins"};
		sell[] ={400,"Coins"};
	};
	class glock17_EP1 {
		type = "trade_weapons";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class Colt1911 {
		type = "trade_weapons";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class M9 {
		type = "trade_weapons";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class MakarovSD {
		type = "trade_weapons";
		buy[] ={800,"Coins"};
		sell[] ={400,"Coins"};
	};
	class revolver_gold_EP1 {
		type = "trade_weapons";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class Makarov {
		type = "trade_weapons";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class revolver_EP1 {
		type = "trade_weapons";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
};
