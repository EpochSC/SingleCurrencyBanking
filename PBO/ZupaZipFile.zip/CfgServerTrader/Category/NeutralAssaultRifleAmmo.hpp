class Category_643 {
	class 30Rnd_556x45_Stanag {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={50,"Coins"};
	};
	class 20Rnd_762x51_FNFAL {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class 30Rnd_545x39_AK {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={50,"Coins"};
	};
	class 30Rnd_762x39_AK47 {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={50,"Coins"};
	};
	class 30Rnd_762x39_SA58 {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
};
class Category_609 {
	class 30Rnd_556x45_Stanag {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={50,"Coins"};
	};
	class 20Rnd_762x51_FNFAL {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class 30Rnd_545x39_AK {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={50,"Coins"};
	};
	class 30Rnd_762x39_AK47 {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={50,"Coins"};
	};
	class 30Rnd_762x39_SA58 {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
};
