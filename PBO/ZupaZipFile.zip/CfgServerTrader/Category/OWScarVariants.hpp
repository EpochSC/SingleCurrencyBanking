class Category_1004 {

class SCAR_L_CQC {type = "trade_weapons";buy[] = {7000,"Coins"};sell[] = {3500,"Coins"};};
class SCAR_L_CQC_CCO_SD {type = "trade_weapons";buy[] = {7400,"Coins"};sell[] = {3550,"Coins"};};
class SCAR_L_CQC_EGLM_Holo {type = "trade_weapons";buy[] = {7600,"Coins"};sell[] = {3580,"Coins"};};
class SCAR_L_CQC_Holo {type = "trade_weapons";buy[] = {7200,"Coins"};sell[] = {3550,"Coins"};};
class SCAR_L_STD_EGLM_RCO {type = "trade_weapons";buy[] = {7600,"Coins"};sell[] = {3580,"Coins"};};
class SCAR_L_STD_HOLO {type = "trade_weapons";buy[] = {7200,"Coins"};sell[] = {3550,"Coins"};};
class SCAR_L_STD_Mk4CQT {type = "trade_weapons";buy[] = {7200,"Coins"};sell[] = {3550,"Coins"};};
class SCAR_H_CQC_CCO {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class SCAR_H_CQC_CCO_SD {type = "trade_weapons";buy[] = {17500,"Coins"};sell[] = {8750,"Coins"};};
class SCAR_H_LNG_Sniper {type = "trade_weapons";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
class SCAR_H_LNG_Sniper_SD {type = "trade_weapons";buy[] = {17500,"Coins"};sell[] = {8750,"Coins"};};
class SCAR_H_STD_EGLM_Spect {type = "trade_weapons";buy[] = {17500,"Coins"};sell[] = {8750,"Coins"};};
};