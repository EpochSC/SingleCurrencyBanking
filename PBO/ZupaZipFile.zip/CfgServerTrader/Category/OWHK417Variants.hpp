class Category_1009 {

class RH_hk417 {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417acog {type = "trade_weapons";buy[] = {17000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417aim {type = "trade_weapons";buy[] = {16000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417eotech {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417s {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417sacog {type = "trade_weapons";buy[] = {17000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417saim {type = "trade_weapons";buy[] = {17000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417sd {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417sdacog {type = "trade_weapons";buy[] = {17000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417sdaim {type = "trade_weapons";buy[] = {16000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417sdeotech {type = "trade_weapons";buy[] = {16000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417sdsp {type = "trade_weapons";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
class RH_hk417seotech {type = "trade_weapons";buy[] = {16000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417sgl {type = "trade_weapons";buy[] = {15000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417sglacog {type = "trade_weapons";buy[] = {17000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417sglaim {type = "trade_weapons";buy[] = {17000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417sgleotech {type = "trade_weapons";buy[] = {17000,"Coins"};sell[] = {7500,"Coins"};};
class RH_hk417sp {type = "trade_weapons";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
};