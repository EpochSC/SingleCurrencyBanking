class Category_997 {
	class 6Rnd_HE_M203 {
		type = "trade_items_old";
		buy[] = {3,"ItemAmethyst"};
		sell[] = {1,"ItemAmethyst"};
	};
	class 5Rnd_127x99_as50 {
		type = "trade_items_old";
		buy[] = {3,"ItemAmethyst"};
		sell[] = {1,"ItemAmethyst"};
	};
	class SMAW_HEAA {
		type = "trade_items_old";
		buy[] = {3,"ItemAmethyst"};
		sell[] = {1,"ItemAmethyst"};
	};
	class 20Rnd_B_AA12_74Slug {
		type = "trade_items_old";
		buy[] = {3,"ItemAmethyst"};
		sell[] = {1,"ItemAmethyst"};
	};
	class 20Rnd_B_AA12_Pellets {
		type = "trade_items_old";
		buy[] = {3,"ItemAmethyst"};
		sell[] = {1,"ItemAmethyst"};
	};
	class PipeBomb {
		type = "trade_items_old";
		buy[] = {5,"ItemAmethyst"};
		sell[] = {2,"ItemAmethyst"};
	};
};

