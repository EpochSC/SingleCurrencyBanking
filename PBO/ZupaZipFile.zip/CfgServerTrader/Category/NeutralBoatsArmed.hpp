class Category_673 {
	class RHIB {
		type = "trade_any_boat";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
};
class Category_558 {
	class RHIB {
		type = "trade_any_boat";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
};
