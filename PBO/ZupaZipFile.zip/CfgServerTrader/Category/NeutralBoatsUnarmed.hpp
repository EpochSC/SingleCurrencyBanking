class Category_672 {
	class Smallboat_1 {
		type = "trade_any_boat";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class Smallboat_2 {
		type = "trade_any_boat";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class Zodiac {
		type = "trade_any_boat";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class Fishing_Boat {
		type = "trade_any_boat";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class PBX {
		type = "trade_any_boat";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class JetSkiYanahui_Case_Red {
		type = "trade_any_boat";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class JetSkiYanahui_Case_Yellow {
		type = "trade_any_boat";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class JetSkiYanahui_Case_Green {
		type = "trade_any_boat";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class JetSkiYanahui_Case_Blue {
		type = "trade_any_boat";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
};
class Category_557 {
	class Smallboat_1 {
		type = "trade_any_boat";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class Smallboat_2 {
		type = "trade_any_boat";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class Zodiac {
		type = "trade_any_boat";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class Fishing_Boat {
		type = "trade_any_boat";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class PBX {
		type = "trade_any_boat";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class JetSkiYanahui_Case_Red {
		type = "trade_any_boat";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class JetSkiYanahui_Case_Yellow {
		type = "trade_any_boat";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class JetSkiYanahui_Case_Green {
		type = "trade_any_boat";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class JetSkiYanahui_Case_Blue {
		type = "trade_any_boat";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
};
