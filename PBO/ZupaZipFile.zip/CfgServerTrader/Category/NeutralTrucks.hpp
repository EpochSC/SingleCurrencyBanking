class Category_590 {
	class hilux1_civil_3_open_EP1 {
		type = "trade_any_vehicle";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class datsun1_civil_3_open {
		type = "trade_any_vehicle";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class hilux1_civil_1_open {
		type = "trade_any_vehicle";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class datsun1_civil_2_covered {
		type = "trade_any_vehicle";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class datsun1_civil_1_open {
		type = "trade_any_vehicle";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class hilux1_civil_2_covered {
		type = "trade_any_vehicle";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
};
